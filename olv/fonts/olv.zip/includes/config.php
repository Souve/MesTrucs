<?php
    ini_set("display_errors", true);
    error_reporting(E_ALL);

    require("constants.php");
    require("functions.php");

    session_start();
	
    if ($_SESSION["user"] == false)
    {
        redirect("login.php");
    }

?>
