<div>
<form action="register.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autofocus class="form-control" name="username" placeholder="Pseudo" type="text"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="password" placeholder="Mot de passe" type="password"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="confirmation" placeholder="Confirmation MP" type="password"/>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Inscription</button>
        </div>
    </fieldset>
</form>
<div>
</div>
