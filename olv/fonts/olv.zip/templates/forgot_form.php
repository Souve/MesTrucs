<form action="forgot.php" method="post">
    <fieldset>
	<h4>Please enter your email adress for reset your password</h4><br /><br />
        <div class="form-group">
            <input autofocus class="form-control" name="email" placeholder="Email" type="text"/>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Reset</button>
        </div>
    </fieldset>
</form>
