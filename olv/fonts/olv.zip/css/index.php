<?php
	header("Location: ../");

?>
