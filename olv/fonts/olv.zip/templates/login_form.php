<form action="login.php" method="post" class="form-signin" role="form">
    <fieldset>
    	<legend>Olv finances</legend>
    	<h2 class="form-signin-heading">Se connecter</h2>
        <div class="form-group">
            <input autofocus class="form-control" name="username" placeholder="Pseudo" type="text"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="password" placeholder="Mot de passe" type="password"/>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Connexion</button>
        </div>
    	<div style="text-align:center;">
			Copyright &#169; 2015 Olivier Finances. <br>Powered by <br> <a id="cop" href="mailto:skavunga@gmail.com" title="Ecrire au developpeur">Souve Kavunga</a> and <a href="mailto:planetepnow@yahoo.fr" title="Ecrire au developpeur">Nowan Kandolo</a>
		</div>
	</fieldset>
</form>

