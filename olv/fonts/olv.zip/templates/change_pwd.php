<div>
<form action="register.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autofocus class="form-control" name="last_pwd" placeholder="Ancien MP" type="password"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="new_pwd" placeholder="Nouveau MP" type="password"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="confirmation_pwd" placeholder="Confirmation MP" type="password"/>
        </div>
        <div class="form-group">
            <button type="submit" name="change_pwd" class="btn btn-default">Modifier</button>
        </div>
    </fieldset>
</form>
<div>
</div>
