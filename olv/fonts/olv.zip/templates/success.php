
<p class="lead text-success">
    <?= htmlspecialchars($message) ?>
</p>

<a href="index.php">Accueil</a>
