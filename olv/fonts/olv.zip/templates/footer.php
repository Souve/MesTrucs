<?php if (isset($_SESSION['user']) && $_SESSION['user'] != false):
	if(!isset($message)) printf('</div>');
	$na = "/olv"
?>	


		<div id="bottom">
			Copyright &#169; 2015 Olivier Finances. <br>Powered by <a href="mailto:skavunga@gmail.com" title="Ecrire au developpeur">Souve Kavunga</a> and <a href="mailto:planetepnow@yahoo.fr" title="Ecrire au developpeur">Nowan Kandolo</a>  
		</div>
		</div>
		
		<div class="col-sm-3">
		<?php if(isset($tarif)): ?>
		  <table class="table table-striped">
			  <thead>
			  		<tr>
			  			<td colspan="2"><div class="btn btn-primary btn-block">Tarification</div></td>
			  		</tr>
			  		<tr>
			  			<th>Marchandise</th>
			  			<th>Prix</th>
			  		</tr>
			  </thead>
			  <tbody>
		  <?php foreach($tarif as $tar): ?>		  
			<tr>
				<td style="text-align:left;"><?=$tar['marchandise']?> </td>
				<td style="text-align:left;">$ <?=number_format($tar['prix'], 2)?></td>
			</tr>
			<?php endforeach; if($_SERVER["PHP_SELF"] == "$na/index.php"): ?>
			<tr>
				<td colspan="2"><a href="index.php?s=modifier" class="btn btn-warning btn-block">MODIFIER</a></td>
			</tr>
			<?php endif; ?>
		  	</tbody>
		  </table>
		  <?php endif; ?>
		  
		  <?php if ($_SERVER['PHP_SELF'] == "$na/rapport.php"): ?>
		  <table class="table table-striped">
			  <thead>
			  		<tr>
			  			<td colspan="3"><div class="btn btn-primary btn-block">Rapports</div></td>
			  		</tr>
			  </thead>
			  <tbody>	  
			<tr>
				<td style="text-align:left;">Jour</td>
				<form method="post" action="rapport.php?s=<?=$_GET['s']?>">
					<td><input type="text" name="jour" placeholder = "JJ-MM-AAAA"></td>
					<td><input type="submit" value = "Valider"></td>
				</form>
			</tr> 
			<tr>
				<td style="text-align:left;">Mois</td>
				<form method="post" action="rapport.php?s=<?=$_GET['s']?>">
					<td><input type="text" name="mois" placeholder = "MM-AAAA"></td>
					<td><input type="submit" value = "Valider"></td>
				</form>
			</tr> 
			<tr>
				<td style="text-align:left;">Année</td>
				<form method="post" action="rapport.php?s=<?=$_GET['s']?>">
					<td><input type="text" name="annee" placeholder = "AAAA"></td>
					<td><input type="submit" value = "Valider"></td>
				</form>
			</tr>
			<tr>
				<td colspan="3"><a href="javascript:window.print();" class="btn btn-success btn-block">Imprimer</a></td>
			</tr>
			</tbody>
			</table>
			<?php endif; if(isset($ag)): ?>
		  <?php if ($_SERVER['REQUEST_URI'] == "$na/inserer.php?s=$ag"): ?>
			  <a href="inserer.php?m=<?=$_GET['s']?>" class="btn btn-default btn-block">Modifier douane</a>
			<?php endif; ?>
		  <?php if ($_SERVER['REQUEST_URI'] == "$na/rembourser.php?s=$ag"): ?>
			  <a href="rembourser.php?m=<?=$_GET['s']?>" class="btn btn-default btn-block">Modifier le rembourse</a>
			<?php endif; endif;?>
		 </div>  
	</div>
</div>
            </div>
            <?php endif ?>
        </div>

    </body>

</html>
