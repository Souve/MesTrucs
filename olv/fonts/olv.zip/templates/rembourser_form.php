<div>
      <form class="form-horizontal " method="post" action="rembourser.php?sv=<?=$ag?>">
          <div class="form-group has-warning">
              <label class="control-label col-lg-5" for="inputWarning">Montant payer</label>
              <div class="col-lg-3">
                  <input type="text" class="form-control" name="rembourser" id="inputWarning" placeholder="Montant en $">
              </div>
          </div>
         <button type="submit" class="btn btn-primary btn-block" value="Boutton">Payer</button>
      </form>
<div>
</div>
