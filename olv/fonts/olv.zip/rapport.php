<?php 
	//Configuration
	require("includes/config.php");
		
	if($_SERVER["REQUEST_METHOD"] == "GET")
	{
		if (isset($_GET['s']) && $_GET['s'] != NULL)
		{
			$rows = query("SELECT * FROM history WHERE agence=? ORDER BY id DESC LIMIT 0,6", $_GET['s']);
			$ag = $_GET['s'];
			
			switch ($ag)
	    	{
	    		case "mkf": case "kabba": case "atc": case "drames": case "sk5": case "pm":
	    			render("history_view.php", ["positions" => $rows, "ag" => $ag,"title" => "Rapports ".strtoupper($ag)]);
	    			break;
	    	}	
		}
		redirect("./");
	}
	else if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$ag =  $_GET['s'];
		$dat = "";	
		if(isset($_GET['s']) && $_GET['s'] != NULL)
		{
			if(isset($_POST['jour']) && $_POST['jour'] != NULL)
			{
				$dat = $_POST['jour'];
			}
			else if(isset($_POST['mois']) && $_POST['mois'] != NULL)
			{
				$dat = $_POST['mois'];
			}
			else if(isset($_POST['annee']) && $_POST['annee'] != NULL)
			{
				$dat = $_POST['annee'];
			}
			
			if($dat == NULL)
			{
				apologize("Definissez soit le jour soit le mois ou année pour pouvoir effectuer des recherches !");
			}
			else if ($ag == NULL)
			{
				apologize("Impossible de traiter votre demande !");
			}
			
			$rows = query("SELECT * FROM history WHERE agence=? AND jour = ? OR mois = ? OR annee = ?", $ag, $dat, $dat, $dat);
			render("history_view.php", ["positions" => $rows, "ag" => $ag,"title" => "Rapports ".strtoupper($ag)]);
					
			
		}
		redirect("./");
	}
?>
