
<p class="lead text-danger">
    <?= htmlspecialchars($message) ?>
</p>

<a href="javascript:history.go(-1);">Retour</a>

