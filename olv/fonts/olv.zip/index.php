<?php

    // configuration
    require("includes/config.php"); 
    
    $mar = query("SELECT * FROM tarif");
    
	
	if ($_SERVER["REQUEST_METHOD"] == "GET")
	{
		
		if(isset($_GET['s']))
 	   	{
 	   		$mkf = query("SELECT * FROM agences WHERE agence = 'mkf' AND qte > 0");
 	   		$kabba = query("SELECT * FROM agences WHERE agence = 'kabba' AND qte > 0");
 	   		$drames = query("SELECT * FROM agences WHERE agence = 'drames' AND qte > 0");
 	   		$sk5 = query("SELECT * FROM agences WHERE agence = 'sk5' AND qte > 0");
 	   		$atc = query("SELECT * FROM agences WHERE agence = 'atc' AND qte > 0");
 	   		$pm = query("SELECT * FROM agences WHERE agence = 'pm' AND qte > 0");
 	   		
 	   		$mkf2 = query("SELECT cash FROM cash WHERE agence = 'mkf'");
 	   		$kabba2 = query("SELECT cash FROM cash WHERE agence = 'kabba'");
 	   		$drames2 = query("SELECT cash FROM cash WHERE agence = 'drames'");
 	   		$sk52 = query("SELECT cash FROM cash WHERE agence = 'sk5'");
 	   		$atc2 = query("SELECT cash FROM cash WHERE agence = 'atc'");
 	   		$pm2 = query("SELECT cash FROM cash WHERE agence = 'pm'");
 	   		
 	   		switch($_GET['s'])
	 	   	{
	 	   		case "modifier":
	 	   			render("modif_tarif.php", ["title" => "Modifier le tarif", "tarif" => $mar]);
	 	   			break;
	 	   		case "mkf":
	 	   			render("agences.php", ["title" => "MKF", "tarif" => $mar, "agence" => $mkf, "cash" => $mkf2]);
	 	   			break;
	 	   		case "kabba":
	 	   			render("agences.php", ["title" => "KABBA", "tarif" => $mar, "agence" => $kabba, "cash" => $kabba2]);
	 	   			break;
	 	   		case "drames":
	 	   			render("agences.php", ["title" => "DRAMES", "tarif" => $mar, "agence" => $drames, "cash" => $drames2]);
	 	   			break;
	 	   		case "sk5":
	 	   			render("agences.php", ["title" => "SK5", "tarif" => $mar, "agence" => $sk5, "cash" => $sk52]);
	 	   			break;
	 	   		case "pm":
	 	   			render("agences.php", ["title" => "PM", "tarif" => $mar, "agence" => $pm, "cash" => $pm2]);
	 	   			break;
	 	   		case "atc":
	 	   			render("agences.php", ["title" => "ATC", "tarif" => $mar, "agence" => $atc, "cash" => $atc2]);
	 	   			break;
	 	   		default:
	 	   			redirect('./');
	 	   			break;
	 	   	}
 	   	}
 	   	else
	 	   	render("accueil.php", ["title" => "Accueil", "tarif" => $mar]);
	}
	else if ($_SERVER["REQUEST_METHOD"] == "POST")
	{
		if(isset($_POST["modif_tarif"]))
		{
			foreach($mar as $modif)
			{
				if(isset($_POST[$modif['marchandise']]) && !empty($_POST[$modif['marchandise']]))
				{
					query("UPDATE tarif SET prix = ? WHERE marchandise=?", $_POST[$modif['marchandise']], $modif['marchandise']);
				}
				else
				{
					apologize("Veuillez remplir la case de ".strtoupper($modif['marchandise']));
				}
			}
			
			redirect("./");
		}
	}
	
	

?>
